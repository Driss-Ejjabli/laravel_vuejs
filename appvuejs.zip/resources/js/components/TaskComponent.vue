<template>
    <div class="container">
        <div class="row justify-content-center">
            <ul class="list-group">
                <li id="list-group-item">Tâche 1</li>
                <li id="list-group-item">Tâche 2</li>
                <li id="list-group-item">Tâche 3</li>
                <li id="list-group-item">Tâche 4</li>
            </ul> 
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
