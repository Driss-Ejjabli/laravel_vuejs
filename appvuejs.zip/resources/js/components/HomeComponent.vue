<template>
    <div class="container">
        <div class="row justify-content-center">
            <h2>Bienvenue</h2>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.');
        }
    }
</script>
